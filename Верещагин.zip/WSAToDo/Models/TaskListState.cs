﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSAToDo.Models
{
    public class TaskListState
    {
        public int startIndex { get; set; }
        public bool FilterOpen { get; set; }
        public bool? isClosed { get; set; }
        public string searchString { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public bool atEndOfList { get; set; }
        public int? TaskSignificancesID { get; set; }

    }
}