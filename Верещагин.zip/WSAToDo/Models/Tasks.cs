﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace WSAToDo.Models
{
    /// <summary>
    /// Задача
    /// </summary>
    public class Tasks
    {
        // ID 
        [Key]
        public int Id { get; set; }
        // Внешний ключ - Пользователь
        [Display(Name = "Пользователь")]
        public int UserID { get; set; }
        public UserProfile User { get; set; }
        // Название
        [Required]
        [Display(Name = "Название ")]
        [MaxLength(50, ErrorMessage = "Превышена максимальная длина записи")]
        public string Name { get; set; }
        // Дата создания

        [Display(Name = "Дата создания ")]
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}", ApplyFormatInEditMode = true)]
        //[DataType(DataType.DateTime)]
        [DataType(DataType.Date)]
        public DateTime CreateDate { get; set; }
        // Описание
        [Required]
        [Display(Name = "Описание ")]
        [MaxLength(1024, ErrorMessage = "Превышена максимальная длина записи")]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }
        // Внешний ключ - Важность
        [Display(Name = "Важность ")]
        public int TaskSignificancesID { get; set; }
        public TaskSignificances TaskSignificances { get; set; }

        // Дата закрытия

        [Display(Name = "Дата выполнения")]
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy H:mm:ss}", ApplyFormatInEditMode = true)]
        [DataType(DataType.DateTime)]
        public DateTime? CloseDate { get; set; }

        [Display(Name = "Состояние")]
        public bool IsClosed { get { return CloseDate != null; } }
    }
}