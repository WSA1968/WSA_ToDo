﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WSAToDo.Models;

namespace WSAToDo.Controllers
{
    /// <summary>
    /// Контроллер ToDo
    /// </summary>
    public class ToDoController : Controller
    {
        UsersContext db = new UsersContext();
        /// кол-во строк на странице
        static int maxRecordInList = 10;
        TaskSignificances unknownTaskSignificances = new TaskSignificances() { Name = "Неизвестно" };

        UserProfile user { get { return db.UserProfiles.FirstOrDefault(m => m.UserName == HttpContext.User.Identity.Name); } }
        //
        // Построитель списка
        [Authorize]
        public ActionResult Index()
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            if (taskListState == null) taskListState = new TaskListState() { startIndex = 0, isClosed = false, fromDate = null, toDate = null, FilterOpen = false, searchString = string.Empty };

            //выбираем задачи пользователя с учетом фиьльтра если есть
            List<Tasks> tasks = db.Tasks.Where(r => r.UserID == user.UserId &&
                (taskListState.searchString == null || taskListState.searchString.Trim() == "" || r.Name.ToUpper().Contains(taskListState.searchString.ToUpper()) ||
                r.Description.ToUpper().Contains(taskListState.searchString.ToUpper())) &&
                (taskListState.fromDate == null || r.CreateDate >= taskListState.fromDate) &&
                (taskListState.toDate == null || r.CreateDate <= taskListState.toDate)&&
                (taskListState.TaskSignificancesID == null || r.TaskSignificancesID == taskListState.TaskSignificancesID))
                                    .OrderBy(r => r.CreateDate).ToList(); // упорядочиваем по дате 
            //убираем не подходящие по закрытости
            if (taskListState.isClosed != null)
            {
                tasks = tasks.Where(t => t.IsClosed == (bool)taskListState.isClosed).ToList();
                ViewBag.Title = "Список " + ((bool)taskListState.isClosed ? "закрытых" : "активных") + " задач";
            }
            else ViewBag.Title = "Список всех задач";
            if (!string.IsNullOrWhiteSpace(taskListState.searchString) || taskListState.fromDate != null || taskListState.toDate != null || taskListState.TaskSignificancesID != null)
                ViewBag.Title += " (отфильтрованный)";
            //оставляем только задачи нужной страницы
            if (taskListState.startIndex < tasks.Count)
            {
                tasks.RemoveRange(0, taskListState.startIndex);
                taskListState.atEndOfList = maxRecordInList >= tasks.Count;
                if (!taskListState.atEndOfList) tasks.RemoveRange(maxRecordInList, tasks.Count - maxRecordInList);
            }
            else taskListState.atEndOfList = true;
            
            //проставляем пустую важность - а вдруг?
            foreach (Tasks t in tasks)
            {
                TaskSignificances ts = db.TaskSignificances.FirstOrDefault(pp => pp.Id == t.TaskSignificancesID);
                t.TaskSignificances = ts == null ? unknownTaskSignificances : ts;
            }
            // сохраняем состояние
            TempData["taskListState"] = taskListState;
            List<TaskSignificances> tsignl = db.TaskSignificances.Where(p => !p.IsDeleted).ToList();
            if (tsignl.Count < 1)
            {
                db.TaskSignificances.Add(new TaskSignificances { Name = "Важная" });
                db.SaveChanges();
                tsignl = db.TaskSignificances.Where(p => !p.IsDeleted).ToList();
            }
            tsignl.Add(new TaskSignificances() { Id = -1, Name = "Любая степень важности" });
            ViewBag.TaskSignificances = new SelectList(tsignl, "Id", "Name");

            ViewBag.TaskListState = taskListState;
            return View("Index", tasks);
        }
        /// <summary>
        /// Все задачи
        /// </summary>
        /// <returns></returns>
        [Authorize]
        public ActionResult IndexAll()
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            if (taskListState != null) { taskListState.isClosed = null; taskListState.startIndex = 0; }
            return RedirectToAction("Index");
        }
        /// <summary>
        /// Активные задачи
        /// </summary>
        /// <returns></returns>
        [Authorize]
        public ActionResult IndexActive()
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            if (taskListState != null) { taskListState.isClosed = false; taskListState.startIndex = 0; }
            return RedirectToAction("Index");
        }
        /// <summary>
        /// Закрытые задачи
        /// </summary>
        /// <returns></returns>
        [Authorize]
        public ActionResult IndexClosed()
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            if (taskListState != null) { taskListState.isClosed = true; taskListState.startIndex = 0; }
            return RedirectToAction("Index");
        }
        /// <summary>
        /// Просмотр задачи
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize]
        public ActionResult Details(int id)
        {
            Tasks task = db.Tasks.FirstOrDefault(p => p.UserID == user.UserId && p.Id == id);
            TaskSignificances ts = db.TaskSignificances.FirstOrDefault(pp => pp.Id == task.TaskSignificancesID);
            task.TaskSignificances = ts == null ? unknownTaskSignificances : ts; 
            return PartialView("_Details", task);
        }
        /// <summary>
        /// Get: Добавление задачи
        /// </summary>
        /// <param name="taskListState"></param>
        /// <returns></returns>
        [Authorize]
        public ActionResult Create()
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            ViewBag.TaskListState = taskListState;
            ViewBag.TaskSignificances = new SelectList(db.TaskSignificances.Where(p => !p.IsDeleted), "Id", "Name");
            Tasks task = new Tasks() { UserID = user.UserId, CreateDate = DateTime.Now };
            return View(task);
        }

        /// <summary>
        /// POST: Создание задачи
        /// </summary>
        /// <param name="taskListState"></param>
        /// <param name="task"></param>
        /// <param name="error"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public ActionResult Create(Tasks task, HttpPostedFileBase error)
        {
            if (ModelState.IsValid)
            {
                task.UserID = user.UserId;
                db.Tasks.Add(task);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            ViewBag.TaskListState = taskListState;
            return View(task);
        }

        /// <summary>
        /// Get: Edit
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize]
        public ActionResult Edit(int id)
        {
            ViewBag.TaskSignificances = new SelectList(db.TaskSignificances.Where(p => !p.IsDeleted), "Id", "Name");
            Tasks taskEdt = db.Tasks.Find(id);
            taskEdt.Name = taskEdt.Name.Trim();
            taskEdt.Description = taskEdt.Description.Trim();
            return View(taskEdt);
        }

        /// <summary>
        /// Post: Edit
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public ActionResult Edit(Tasks task)
        {
            if (ModelState.IsValid)
            {
                task.UserID = user.UserId;
                Tasks taskEdt = db.Tasks.Find(task.Id);
                taskEdt.Name = task.Name.Trim();
                taskEdt.Description = task.Description.Trim();
                taskEdt.CreateDate = task.CreateDate;
                taskEdt.TaskSignificancesID = task.TaskSignificancesID;
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        //
        // GET: /ToDo/Delete/
        [Authorize]
        public ActionResult Delete(int id)
        {
            Tasks task = db.Tasks.FirstOrDefault(p => p.UserID == user.UserId && p.Id == id);
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            ViewBag.TaskListState = taskListState;
            return PartialView("_ToDelete", task);
        }

        //
        // POST: /ToDo/Delete/
        [Authorize]
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            // TODO: Add delete logic here
            Tasks task = db.Tasks.FirstOrDefault(p => p.UserID == user.UserId && p.Id == id);
            db.Tasks.Remove(task);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        /// <summary>
        /// Закрытие задачи
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult CloseTask(int id)
        {
            if (ModelState.IsValid)
            {
                Tasks task = db.Tasks.Find(id);
                task.CloseDate = DateTime.Now;
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        /// <summary>
        /// Фильтр по залачам
        /// </summary>
        /// <param name="name"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public ActionResult TaskSearch(string name, object FromDate, object ToDate, object tsdksignID)
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            if (taskListState != null)
            {
                taskListState.searchString = name;
                DateTime d;
                int n;
                if (FromDate != null && DateTime.TryParseExact(((string[])FromDate)[0], "dd.MM.yyyy",
                       System.Globalization.CultureInfo.InvariantCulture,
                       System.Globalization.DateTimeStyles.None, out d)) taskListState.fromDate = d;
                else taskListState.fromDate = null;
                if (ToDate != null && DateTime.TryParseExact(((string[])ToDate)[0], "dd.MM.yyyy",
                       System.Globalization.CultureInfo.InvariantCulture,
                       System.Globalization.DateTimeStyles.None, out d)) taskListState.toDate = d;
                else taskListState.toDate = null;
                if (tsdksignID != null && int.TryParse(((string[])tsdksignID)[0], out n)) taskListState.TaskSignificancesID = n > 0 ? (int?)n : null;
                else taskListState.TaskSignificancesID = null;
                taskListState.FilterOpen = false;
                taskListState.startIndex = 0;
            }
            return Index();
        }
        /// <summary>
        /// Отображение полей фильтра
        /// </summary>
        /// <returns></returns>
        [Authorize]
        public ActionResult ShowFilter()
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            if (taskListState != null) taskListState.FilterOpen = true;
            return RedirectToAction("Index");
        }
        /// <summary>
        /// Переход на следующую страницу
        /// </summary>
        /// <returns></returns>
        public ActionResult NextTen()
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            if (!taskListState.atEndOfList) taskListState.startIndex += maxRecordInList;
            return RedirectToAction("Index");
        }
        /// <summary>
        /// Переход на предыдущую страницу
        /// </summary>
        /// <returns></returns>
        public ActionResult PrevTen()
        {
            TaskListState taskListState = (TaskListState)TempData["taskListState"];
            if (taskListState != null)
            {
                if (taskListState.startIndex > maxRecordInList) taskListState.startIndex -= maxRecordInList;
                else taskListState.startIndex = 0;
            }
            return RedirectToAction("Index");
        }
    }
}
