﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WSAToDo.Models;

namespace WSAToDo.Controllers
{
    /// <summary>
    /// Работа со справичником степеней важности
    /// </summary>
    public class ServiceController : Controller
    {
        UsersContext db = new UsersContext();

        // Список степеней важности
        [Authorize]
        [HttpGet]
        public ActionResult TaskSignificances()
        {
            ViewBag.TaskSignificances = db.TaskSignificances.Where(p => !p.IsDeleted);
            return View();
        }

        // Добавление степени важности
        [Authorize]
        [HttpPost]
        public ActionResult TaskSignificances(TaskSignificances taskSign)
        {
            if (ModelState.IsValid)
            {
                db.TaskSignificances.Add(taskSign);
                db.SaveChanges();
            }
            ViewBag.TaskSignificances = db.TaskSignificances.Where(p => !p.IsDeleted);
            return View(taskSign);
        }
        // Удаление отдела по id
        [Authorize]
        public ActionResult DeleteTaskSignificances(int id)
        {
            TaskSignificances taskSign = db.TaskSignificances.Find(id);
            taskSign.IsDeleted = true;
            db.SaveChanges();
            return RedirectToAction("TaskSignificances");
        }

    }
}
